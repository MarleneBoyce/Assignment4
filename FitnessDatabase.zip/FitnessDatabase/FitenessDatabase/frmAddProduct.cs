﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogueFitness
{
    public partial class frmAddProduct : Form
    {
        private FitnessDatabase.RogueFitnessEntities dbContext = new FitnessDatabase.RogueFitnessEntities();

        private int counter;

        public frmAddProduct()
        {
            InitializeComponent();
        }

        private void frmAddProduct_Load(object sender, EventArgs e)
        {
            // This should all occur before 
            // frmAddProduct is even loaded.

            // set counter to the value (or next value in the database
            if (!dbContext.Products.Any())
                counter = 1;
            else
                counter = dbContext.Products.Max(Products => Products.ID) + 1;

            txtID.Text = counter.ToString();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            // dbContext.Products
            FitnessDatabase.Product product = new FitnessDatabase.Product();
                        
            product.Name = txtName.Text;
            product.Price = decimal.Parse(txtPrice.Text);

            dbContext.Products.Add(product);

            dbContext.SaveChanges();
            
            MessageBox.Show(this, "Product has been saved to our database", "PRODUCT SAVED", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Save the added product data to file
            counter = dbContext.Products.Max(Products => Products.ID) + 1;
            txtID.Text = counter.ToString();

            txtName.Clear();
            txtPrice.Clear();
         
        }
        
        private void btnMenu_Click(object sender, EventArgs e)
        {
            // return to Menu screen (frmWelcome)
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

    }
}
