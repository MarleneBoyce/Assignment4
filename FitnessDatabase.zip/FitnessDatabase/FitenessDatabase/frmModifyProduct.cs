﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogueFitness
{
    public partial class frmModifyProduct : Form
    {        
        private FitnessDatabase.RogueFitnessEntities dbContext = new FitnessDatabase.RogueFitnessEntities();

        private List<FitnessDatabase.Product> products;

        private int index;
                         
        public frmModifyProduct()
        {
            InitializeComponent();

            if (dbContext.Products.Any())
            {
                products = dbContext.Products.ToList();

                index = 0;

                ChangeView();
            }
            else
                txtID.Text = "1";
        }

        private void frmModifyProduct_Load(object sender, EventArgs e)
        {
            // set counter to the value (or next value in the database

            if (dbContext.Products.Any())
            {
                index = 0;

                ChangeView();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            if (index > 0)
                index--;

            ChangeView();

            Refresh();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            // return to menu screen (frmWelcome)
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (index < products.Count - 1)
                index++;

            ChangeView();

            Refresh();
        }


        private void ChangeView()
        {
            txtID. Text = products[index].ID.ToString();
            txtName.Text = products[index].Name;
            txtPrice.Text = string.Format("{0:f2}", products[index].Price.ToString());
        }
        
    }
}
