﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogueFitness
{
    public partial class frmTransactions : Form
    {
        private FitnessDatabase.RogueFitnessEntities dbContext = new FitnessDatabase.RogueFitnessEntities();

        public frmTransactions()
        {
            InitializeComponent();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            // return to Menu screen (frmWelcome)
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSearch.Text != "" )
            {
                var products = from product in dbContext.Products
                               where product.Name == txtSearch.Text
                               select new { product.ID, product.Name, product.Price };

                foreach (var p in products)
                {
                    txtTranactions.AppendText("ID: " + p.ID + Environment.NewLine +
                                         "Name: " + p.Name + Environment.NewLine +
                                         "Price: " + string.Format("{0:f2}", p.Price.ToString()) + Environment.NewLine);
                }
            }
        }
    }
}
