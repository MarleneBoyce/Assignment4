﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RogueFitness
{
    public partial class frmWelcome : Form
    {
        public frmWelcome()
        {
            InitializeComponent();
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            // This hides the Welcome Form
            this.Hide();
          
            // This opens the Add Product Form
            Form productForm = new frmAddProduct();
            productForm.ShowDialog();

            // This displays the Welcome form again
            this.Show();
        }

        private void btnAddOrder_Click(object sender, EventArgs e)
        {
            // This hides the Welcome Form
            this.Hide();

            // This opens the Add Order Form
            Form modifyForm = new frmModifyProduct();
            modifyForm.ShowDialog();

            // This displays the Welcome form again
            this.Show();
        }

        private void btnTransactions_Click(object sender, EventArgs e)
        {
            // This hides the Welcome Form
            this.Hide();

            // This opens the Transactions Form
            Form transactionForm = new frmTransactions();
            transactionForm.ShowDialog();

            // This displays the Welcome form again
            this.Show();
        }
    }
}
